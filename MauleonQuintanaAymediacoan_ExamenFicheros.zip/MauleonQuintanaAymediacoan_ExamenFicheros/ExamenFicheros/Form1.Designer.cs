﻿namespace ExamenFicheros
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.set3j2 = new System.Windows.Forms.NumericUpDown();
            this.set2j2 = new System.Windows.Forms.NumericUpDown();
            this.set3j1 = new System.Windows.Forms.NumericUpDown();
            this.set1j2 = new System.Windows.Forms.NumericUpDown();
            this.set2j1 = new System.Windows.Forms.NumericUpDown();
            this.set1j1 = new System.Windows.Forms.NumericUpDown();
            this.NumPatido = new System.Windows.Forms.NumericUpDown();
            this.comboJugador2 = new System.Windows.Forms.ComboBox();
            this.dataGridResult = new System.Windows.Forms.DataGridView();
            this.CPartido = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CJugador1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CJugador2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CSets1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CSets2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tbJugador1 = new System.Windows.Forms.TextBox();
            this.BGraba = new System.Windows.Forms.Button();
            this.BLee = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.combotab2 = new System.Windows.Forms.ComboBox();
            this.BOrdena = new System.Windows.Forms.Button();
            this.dataGrandSlams = new System.Windows.Forms.DataGridView();
            this.CJudagor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CResultado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label4 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.set3j2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.set2j2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.set3j1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.set1j2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.set2j1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.set1j1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumPatido)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridResult)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrandSlams)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(6, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(692, 342);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.set3j2);
            this.tabPage1.Controls.Add(this.set2j2);
            this.tabPage1.Controls.Add(this.set3j1);
            this.tabPage1.Controls.Add(this.set1j2);
            this.tabPage1.Controls.Add(this.set2j1);
            this.tabPage1.Controls.Add(this.set1j1);
            this.tabPage1.Controls.Add(this.NumPatido);
            this.tabPage1.Controls.Add(this.comboJugador2);
            this.tabPage1.Controls.Add(this.dataGridResult);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.listBox1);
            this.tabPage1.Controls.Add(this.tbJugador1);
            this.tabPage1.Controls.Add(this.BGraba);
            this.tabPage1.Controls.Add(this.BLee);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(684, 316);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Partidos";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // set3j2
            // 
            this.set3j2.Location = new System.Drawing.Point(413, 112);
            this.set3j2.Maximum = new decimal(new int[] {
            7,
            0,
            0,
            0});
            this.set3j2.Name = "set3j2";
            this.set3j2.Size = new System.Drawing.Size(40, 20);
            this.set3j2.TabIndex = 6;
            // 
            // set2j2
            // 
            this.set2j2.Location = new System.Drawing.Point(340, 112);
            this.set2j2.Maximum = new decimal(new int[] {
            7,
            0,
            0,
            0});
            this.set2j2.Name = "set2j2";
            this.set2j2.Size = new System.Drawing.Size(40, 20);
            this.set2j2.TabIndex = 6;
            // 
            // set3j1
            // 
            this.set3j1.Location = new System.Drawing.Point(413, 73);
            this.set3j1.Maximum = new decimal(new int[] {
            7,
            0,
            0,
            0});
            this.set3j1.Name = "set3j1";
            this.set3j1.Size = new System.Drawing.Size(40, 20);
            this.set3j1.TabIndex = 6;
            // 
            // set1j2
            // 
            this.set1j2.Location = new System.Drawing.Point(273, 112);
            this.set1j2.Maximum = new decimal(new int[] {
            7,
            0,
            0,
            0});
            this.set1j2.Name = "set1j2";
            this.set1j2.Size = new System.Drawing.Size(40, 20);
            this.set1j2.TabIndex = 6;
            // 
            // set2j1
            // 
            this.set2j1.Location = new System.Drawing.Point(340, 73);
            this.set2j1.Maximum = new decimal(new int[] {
            7,
            0,
            0,
            0});
            this.set2j1.Name = "set2j1";
            this.set2j1.Size = new System.Drawing.Size(40, 20);
            this.set2j1.TabIndex = 6;
            // 
            // set1j1
            // 
            this.set1j1.Location = new System.Drawing.Point(273, 71);
            this.set1j1.Maximum = new decimal(new int[] {
            7,
            0,
            0,
            0});
            this.set1j1.Name = "set1j1";
            this.set1j1.Size = new System.Drawing.Size(40, 20);
            this.set1j1.TabIndex = 6;
            // 
            // NumPatido
            // 
            this.NumPatido.Location = new System.Drawing.Point(122, 30);
            this.NumPatido.Name = "NumPatido";
            this.NumPatido.Size = new System.Drawing.Size(40, 20);
            this.NumPatido.TabIndex = 6;
            // 
            // comboJugador2
            // 
            this.comboJugador2.FormattingEnabled = true;
            this.comboJugador2.Items.AddRange(new object[] {
            "NADAL",
            "FEDERER",
            "DJOKOVIC",
            "MURRAY"});
            this.comboJugador2.Location = new System.Drawing.Point(122, 111);
            this.comboJugador2.Name = "comboJugador2";
            this.comboJugador2.Size = new System.Drawing.Size(121, 21);
            this.comboJugador2.TabIndex = 5;
            // 
            // dataGridResult
            // 
            this.dataGridResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridResult.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CPartido,
            this.CJugador1,
            this.CJugador2,
            this.CSets1,
            this.CSets2});
            this.dataGridResult.Location = new System.Drawing.Point(122, 176);
            this.dataGridResult.Name = "dataGridResult";
            this.dataGridResult.ReadOnly = true;
            this.dataGridResult.Size = new System.Drawing.Size(541, 124);
            this.dataGridResult.TabIndex = 4;
            // 
            // CPartido
            // 
            this.CPartido.HeaderText = "Partido";
            this.CPartido.Name = "CPartido";
            this.CPartido.ReadOnly = true;
            // 
            // CJugador1
            // 
            this.CJugador1.HeaderText = "Jugador 1";
            this.CJugador1.Name = "CJugador1";
            this.CJugador1.ReadOnly = true;
            // 
            // CJugador2
            // 
            this.CJugador2.HeaderText = "Jugador 2";
            this.CJugador2.Name = "CJugador2";
            this.CJugador2.ReadOnly = true;
            // 
            // CSets1
            // 
            this.CSets1.HeaderText = "Sets 1";
            this.CSets1.Name = "CSets1";
            this.CSets1.ReadOnly = true;
            // 
            // CSets2
            // 
            this.CSets2.HeaderText = "Sets 2";
            this.CSets2.Name = "CSets2";
            this.CSets2.ReadOnly = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Jugador 2:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Jugador 1:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Partido:";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Items.AddRange(new object[] {
            "NADAL",
            "FEDERER",
            "DJOKOVIC",
            "MURRAY"});
            this.listBox1.Location = new System.Drawing.Point(543, 17);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 69);
            this.listBox1.TabIndex = 2;
            this.listBox1.DoubleClick += new System.EventHandler(this.listBox1_DoubleClick);
            // 
            // tbJugador1
            // 
            this.tbJugador1.Location = new System.Drawing.Point(122, 73);
            this.tbJugador1.Name = "tbJugador1";
            this.tbJugador1.Size = new System.Drawing.Size(121, 20);
            this.tbJugador1.TabIndex = 1;
            // 
            // BGraba
            // 
            this.BGraba.Location = new System.Drawing.Point(21, 176);
            this.BGraba.Name = "BGraba";
            this.BGraba.Size = new System.Drawing.Size(75, 50);
            this.BGraba.TabIndex = 0;
            this.BGraba.Text = "Graba";
            this.BGraba.UseVisualStyleBackColor = true;
            this.BGraba.Click += new System.EventHandler(this.BGraba_Click);
            // 
            // BLee
            // 
            this.BLee.Location = new System.Drawing.Point(21, 250);
            this.BLee.Name = "BLee";
            this.BLee.Size = new System.Drawing.Size(75, 50);
            this.BLee.TabIndex = 0;
            this.BLee.Text = "Lee";
            this.BLee.UseVisualStyleBackColor = true;
            this.BLee.Click += new System.EventHandler(this.BLee_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.combotab2);
            this.tabPage2.Controls.Add(this.BOrdena);
            this.tabPage2.Controls.Add(this.dataGrandSlams);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(684, 316);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Clasificación";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // combotab2
            // 
            this.combotab2.FormattingEnabled = true;
            this.combotab2.Items.AddRange(new object[] {
            "NADAL",
            "FEDERER",
            "DJOKOVIC",
            "MURRAY"});
            this.combotab2.Location = new System.Drawing.Point(306, 70);
            this.combotab2.Name = "combotab2";
            this.combotab2.Size = new System.Drawing.Size(121, 21);
            this.combotab2.TabIndex = 6;
            this.combotab2.SelectionChangeCommitted += new System.EventHandler(this.combotab2_SelectionChangeCommitted);
            // 
            // BOrdena
            // 
            this.BOrdena.Location = new System.Drawing.Point(41, 212);
            this.BOrdena.Name = "BOrdena";
            this.BOrdena.Size = new System.Drawing.Size(75, 50);
            this.BOrdena.TabIndex = 4;
            this.BOrdena.Text = "Ordena";
            this.BOrdena.UseVisualStyleBackColor = true;
            this.BOrdena.Click += new System.EventHandler(this.Ordena);
            // 
            // dataGrandSlams
            // 
            this.dataGrandSlams.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrandSlams.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CJudagor,
            this.CResultado});
            this.dataGrandSlams.Location = new System.Drawing.Point(28, 24);
            this.dataGrandSlams.Name = "dataGrandSlams";
            this.dataGrandSlams.Size = new System.Drawing.Size(240, 150);
            this.dataGrandSlams.TabIndex = 3;
            // 
            // CJudagor
            // 
            this.CJudagor.HeaderText = "Jugador";
            this.CJudagor.Name = "CJudagor";
            // 
            // CResultado
            // 
            this.CResultado.HeaderText = "Grand Slams";
            this.CResultado.Name = "CResultado";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(339, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Jugador:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(710, 353);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.set3j2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.set2j2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.set3j1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.set1j2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.set2j1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.set1j1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumPatido)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridResult)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrandSlams)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.NumericUpDown set3j2;
        private System.Windows.Forms.NumericUpDown set2j2;
        private System.Windows.Forms.NumericUpDown set3j1;
        private System.Windows.Forms.NumericUpDown set1j2;
        private System.Windows.Forms.NumericUpDown set2j1;
        private System.Windows.Forms.NumericUpDown set1j1;
        private System.Windows.Forms.NumericUpDown NumPatido;
        private System.Windows.Forms.ComboBox comboJugador2;
        private System.Windows.Forms.DataGridView dataGridResult;
        private System.Windows.Forms.DataGridViewTextBoxColumn CPartido;
        private System.Windows.Forms.DataGridViewTextBoxColumn CJugador1;
        private System.Windows.Forms.DataGridViewTextBoxColumn CJugador2;
        private System.Windows.Forms.DataGridViewTextBoxColumn CSets1;
        private System.Windows.Forms.DataGridViewTextBoxColumn CSets2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox tbJugador1;
        private System.Windows.Forms.Button BGraba;
        private System.Windows.Forms.Button BLee;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button BOrdena;
        private System.Windows.Forms.DataGridView dataGrandSlams;
        private System.Windows.Forms.DataGridViewTextBoxColumn CJudagor;
        private System.Windows.Forms.DataGridViewTextBoxColumn CResultado;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox combotab2;
    }
}

