﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;

namespace ExamenFicheros
{
    public partial class Form1 : Form
    {
        Fichero _f1;
        List<string> l1;
        List<Tipo> l2;
        List<string> _cajas;
        private int partido;
        private string jugador1;
        private string jugador2;
        private int sets1;
        private int sets2;

        public Form1()
        {
            InitializeComponent();
        }

        private void BGraba_Click(object sender, EventArgs e)
        {
            try
            {
                if (_f1.abre())
                {
                    _f1.fin();
                    carga(_cajas);
                    _f1.escribe(_cajas);
                }
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
            finally
            {
                _f1.cierra();
            }
        }

        private void listBox1_DoubleClick(object sender, EventArgs e)
        {
            tbJugador1.Text = listBox1.SelectedItem.ToString();
        }

        private void BLee_Click(object sender, EventArgs e)
        {
            int i = 0;
            List<string> caja3;
            caja3 = new List<string>();
            _f1.abre();
            dataGridResult.Rows.Clear();
            for (i = 0; i < _f1.numRegistros; i++)
            {
                caja3.Clear();
                try
                {
                    caja3 = _f1.Lee();

                    dataGridResult.Rows.Add(caja3[0], caja3[1], caja3[2], caja3[3], caja3[4]);
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.Message);
                }
            }
            _f1.cierra();
        }

        void carga(List<string> cajas)
        {
            partido = Convert.ToInt32(NumPatido.Value);
            jugador1 = tbJugador1.Text;
            jugador2 = comboJugador2.SelectedItem.ToString();
            Calcula();
            cajas.Clear();
            cajas.Add(partido.ToString());
            cajas.Add(jugador1);
            cajas.Add(jugador2);
            cajas.Add(sets1.ToString());
            cajas.Add(sets2.ToString());
        }
        private void Crea()
        {
            l1 = new List<string>();
            l2 = new List<Tipo>();
            _cajas = new List<string>();
            l1.Add("Partido");
            l1.Add("Jugador 1");
            l1.Add("Jugador 2");
            l1.Add("Sets 1");
            l1.Add("Sets 2");
            l2.Add(Tipo.entero);
            l2.Add(Tipo.cadena);
            l2.Add(Tipo.cadena);
            l2.Add(Tipo.entero);
            l2.Add(Tipo.entero);
            try
            {
                _f1 = new Fichero("Resultado.dat", l1, l2);
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
                return;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Crea();
        }
        /// <summary>
        /// Suma los puntos de set para determinar el ganador.
        /// </summary>
        private void Calcula()
        {
            int j1 = 0;
            int j2 = 0;
            if (set1j1.Value > set1j2.Value)
                j1++;
            else
                j2++;
            if (set2j1.Value > set2j2.Value)
                j1++;
            else
                j2++;
            if (set3j1.Value > set3j2.Value)
                j1++;
            else
                j2++;
            sets1 = j1;
            sets2 = j2;
        }
        /// <summary>
        /// A partir del jugador seleccionado en el combobox llama a la función buscaganador y escribe en el datagrid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void combotab2_SelectionChangeCommitted(object sender, EventArgs e)
        {
            string seleccion = combotab2.SelectedItem.ToString();
            List<string> caja3;
            caja3 = new List<string>();
            _f1.abre();
            int total = BuscaGanador(caja3, seleccion);
            caja3.Clear();
            try
            {
                dataGrandSlams.Rows.Add(seleccion, total);
                
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
            _f1.cierra();
        }
        /// <summary>
        /// Hace una busqueda por el fichero y en el registro que coincida el nombre selecionado, va sumando la veces ganadas.
        /// </summary>
        /// <param name="caja3"></param>
        /// <param name="seleccion">Jugador seleccionado desde combobox</param>
        /// <returns>Devuelde el total de veces ganadas</returns>
        private int BuscaGanador(List<string> caja3, string seleccion)
        {
            int total = 0;
            int i = 0;
            for (i = 0; i < _f1.numRegistros; i++)
            {
                caja3 = _f1.Lee();
                if (seleccion == caja3[1])
                {
                    if (Convert.ToInt32(caja3[3]) > 1)
                        total++;
                }
                if (seleccion == caja3[2])
                {
                    if (Convert.ToInt32(caja3[4]) > 1)
                        total++;
                }
            }
            return total;
        }
        /// <summary>
        /// Ordena el datagridview en modo descendente.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Ordena(object sender, EventArgs e)
        {
            int i = 0;
            for (i = 0; i < _f1.numRegistros; i++)
            {
                try
                {
                    dataGrandSlams.Sort(dataGrandSlams.Columns[1],ListSortDirection.Descending);
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.Message);
                }
            }
            _f1.cierra();
        }
    }
}
